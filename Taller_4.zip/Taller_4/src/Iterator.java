import java.util.LinkedList;

public class Iterator {
    //Instanciamos una linkedList
    LinkedList<String> nodo = new LinkedList<String>();
}
