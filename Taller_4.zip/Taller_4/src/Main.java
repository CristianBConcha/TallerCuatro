public class Main {
    public static void main(String[] args) {

        /**
         *Sistema para iniciar codigo
         */
        PokedexImpl sistema = new PokedexImpl();



    }
}